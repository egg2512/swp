import React from "react";
import tieuchuan from "../../img/tieuchuan.png";

const tieuchuanList = [
  {
    icon: "📇",
    text: "Mang theo chứng minh nhân dân/hộ chiếu",
  },
  {
    icon: "🦠",
    text: "Không mắc hoặc không có các hành vi nguy cơ lây nhiễm HIV, không nhiễm viêm gan B, viêm gan C, và các virus lây qua đường truyền máu",
  },
  {
    icon: "💉",
    text: "Không nghiện ma túy, rượu bia và các chất kích thích",
  },
  {
    icon: "⚖️",
    text: "Cân nặng: Nam ≥ 45 kg Nữ ≥ 45 kg",
  },
  {
    icon: "💓",
    text: "Không mắc các bệnh mãn tính hoặc cấp tính về tim mạch, huyết áp, hô hấp, dạ dày…",
  },
  {
    icon: "🩸",
    text: "Chỉ số huyết sắc tố (Hb) ≥120g/l (≥125g/l nếu hiến từ 350ml trở lên).",
  },
  {
    icon: "🔞",
    text: "Người khỏe mạnh trong độ tuổi từ đủ 18 đến 60 tuổi",
  },
  {
    icon: "📅",
    text: "Thời gian tối thiểu giữa 2 lần hiến máu là 12 tuần đối với cả Nam và Nữ",
  },
  {
    icon: "🧪",
    text: "Kết quả test nhanh âm tính với kháng nguyên bề mặt của siêu vi B",
  },
];

const Tieuchuan = () => {
  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#21589F",
        display: "flex",
        justifyContent: "center",
        alignItems: "flex-start",
        padding: "40px 0",
      }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "400px 1fr",
          gap: 32,
          width: "90%",
          maxWidth: 1500,
        }}
      >
        {/* Hình ảnh với tiêu đề đè lên */}
        <div style={{ position: "relative", width: "100%", height: 320 }}>
          <img
            src={tieuchuan}
            alt="Tiêu chuẩn"
            style={{
              width: "100%",
              height: 320,
              objectFit: "cover",
              borderRadius: 16,
              boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
              background: "#fff",
              display: "block",
            }}
          />
          <div
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              color: "#21589F",
              fontWeight: 700,
              fontSize: 48,
              lineHeight: 1.1,
              textAlign: "center",
              background: "rgba(255,255,255,0.0)",
              zIndex: 2,
              padding: 24,
              letterSpacing: 1,
              userSelect: "none",
            }}
          >
            Tiêu chuẩn tham
            <br /> gia hiến máu
          </div>
        </div>
        {/* Grid các tiêu chí */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 24,
          }}
        >
          {tieuchuanList.map((item, idx) => (
            <div
              key={idx}
              style={{
                background: "#fff",
                borderRadius: 12,
                padding: "24px 20px",
                display: "flex",
                alignItems: "flex-start",
                gap: 16,
                boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                minHeight: 120,
              }}
            >
              <span
                style={{
                  fontSize: 32,
                  background: "#21589F",
                  color: "#fff",
                  borderRadius: 8,
                  padding: 10,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  minWidth: 48,
                  minHeight: 48,
                }}
              >
                {item.icon}
              </span>
              <span style={{ fontSize: 18, color: "#222" }}>{item.text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Tieuchuan;