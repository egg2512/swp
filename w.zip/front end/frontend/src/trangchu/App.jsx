import React, { useState } from 'react';
import './App.css';
import logo from '../../img/logo.png';
import chu from '../../img/chu.png';
import hinh1 from '../../img/hinh1.png';
import QuyenLoiSection from './QuyenLoiSection';
import Tieuchuan from './tieuchuan';

const App = () => {
  // State lưu trữ ngày bắt đầu và kết thúc khi chọn lịch
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  return (
    // Khối chính của form hiến máu
    <div className="blood-donation-form">
      {/* Thanh header trên cùng */}
      <div className="header-bar">
        {/* Chọn ngôn ngữ */}
        <div
          className="header-left"
          style={{
            gap: 4,
            marginLeft: 20, // Sích vào trong nhiều hơn
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <span className="lang-active">VN</span>
          <span
            className="lang-divider"
            style={{ fontWeight: 300, fontSize: 16, margin: '0 2px' }}
          >/</span>
          <span className="lang-inactive">EN</span>
        </div>
        {/* Logo trung tâm */}
        <div className="header-center">
          <img src={logo} alt="Logo hiến máu" className="logo-center" />
          <img src={chu} alt="Logo chữ" className="logo-chu" />
        </div>
        {/* Đăng nhập */}
        <div
          className="header-right"
          style={{
            gap: 4,
            marginRight: 20, // Sích vào trong nhiều hơn
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <span className="login-icon">👤</span>
          <span className="login-text">Đăng nhập</span>
        </div>
      </div>

      {/* Thanh menu điều hướng */}
      <nav className="main-menu" style={{ marginTop: 0 }}>
        <a href="#">TRANG CHỦ</a>
        <a href="#">HỎI - ĐÁP</a>
        <a href="#">TƯƠNG THÍCH</a>
        <a href="#">LIÊN HỆ</a>
      </nav>
      {/* Thêm hình 1 vào trang */}
      <div className="image-section" style={{ position: 'relative', textAlign: 'center', marginTop: 0, paddingTop: 0 }}>
        <img
          src={hinh1}
          alt="Hình 1"
          style={{ 
            maxWidth: '100%', 
            height: 'auto', 
            borderRadius: 0, 
            display: 'block', 
            marginTop: 0, 
            paddingTop: 0 
          }}
        />
        {/* Lớp phủ mờ màu đen */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            background: 'rgba(0,0,0,0.22)', // Tăng giảm 0.22 để mờ nhiều hay ít
            zIndex: 1,
            pointerEvents: 'none'
          }}
        />
        {/* Overlay slogan */}
        <div
          style={{
            position: 'absolute',
            top: 150, 
            left: 0,
            right: 0,
            margin: '0 auto',
            color: '#fff',
            fontWeight: 'bold',
            fontSize: '2rem',
            textShadow: '0 2px 8px rgba(0,0,0,0.85), 0 0 12px #fff',
            width: '100%',
            maxWidth: 1200,
            padding: '12px 10px 0 10px',
            pointerEvents: 'none',
            whiteSpace: 'normal',
            textAlign: 'center',
            letterSpacing: '1px',
            lineHeight: 1.2,
            textTransform: 'uppercase',
            zIndex: 2,
            boxSizing: 'border-box',
          }}
        >
          <div>
            Hãy làm thế giới tốt đẹp hơn bằng{' '}
            <span style={{
              color: '#e53935', // màu đỏ
              fontWeight: 900,
              textShadow: '0 2px 8px rgba(229,57,53,0.25), 0 0 12px #fff'
            }}>
              giọt máu
            </span> của bạn.
          </div>
          
          <div
            style={{
              fontSize: '1.05rem',
              fontWeight: 500,
              color: '#ffc107',
              textShadow: '0 2px 8px rgba(255,193,7,0.25), 0 0 12px #fff',
              marginTop: 8,
              textTransform: 'none',
              letterSpacing: 0,
            }}
          >
            Mỗi giọt máu cho đi là một cuộc đời ở lại. Hãy cùng chúng tôi đảm bảo nguồn máu ổn định cho những người cần.
          </div>
          {/* Nút đặt lịch hiến máu */}
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 24 }}>
            <button
              className="blink-button"
              onClick={() => alert('Chức năng đặt lịch sẽ sớm ra mắt!')}
            >
              ĐẶT LỊCH HIẾN MÁU
            </button>
          </div>
        </div>


      </div>
      <QuyenLoiSection />
      <Tieuchuan />
    </div>

  );

};

export default App;
